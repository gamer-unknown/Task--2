<!DOCTYPE html>
<html>

<head>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
    <script type="text/javascript" charset="utf8" src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <meta charset="UTF-8">
    <title>Thin Client Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url('../assets/stats.png') no-repeat center center fixed;
            background-size: cover;
            min-height: 60vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }

        .header {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            top: 0;
        }

        .options {
            margin-left: 20px;
            display: flex;
            align-items: center;
        }

        .options a {
            color: white;
            text-decoration: none;
            margin-right: 20px;
            cursor: pointer;
        }

    </style>
</head>

<body>
    <form method="post">
        <label for="dropdown"></label>
        <select id="dropdown" name="selected_option">
            <option value="EIG">EIG</option>
            <option value="MSG">MSG</option>
            <option value="MC&MFCG">MC&MFCG</option>
            <option value="RDTG">RDTG</option>
            <option value="FRFCF">FRFCF</option>
            <option value="ESG">ESG</option>
            <option value="SQ&MRG">SQ&MRG</option>
            <option value="RpG">RpG</option>
            <option value="MMG">MMG</option>
            <option value="RFG">RFG</option>
            <option value="IC">IC</option>
            <option value="CEG">CEG</option>
            <option value="DPS">DPS</option>
            <option value="MG">MG</option>
            <option value="SQRMG">SQRMG</option>
            <option value="NRB">NRB</option>
            <option value="MCMFCG">MCMFCG</option>
            <option value="IGC">IGC</option>
            <option value="DAE">DAE</option>
            <option value="BHAVINI">BHAVINI</option>
            <option value="HSEG">HSEG</option>
        </select>

        <label for="start-date">Start Date:</label>
        <input type="date" id="start-date" name="start-date" required>
        <label for="end-date">End Date:</label>
        <input type="date" id="end-date" name="end-date">
        <input id="submit-button" type="submit" value="Submit">
    </form>
    </div>
    </div>
</body>

</html>
<html>

<head>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            font-size: 16px;
        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<br>

<body>
    <div class="header">
        <div class="options">
            <a href="table">Table</a>
            <a href="graph">Graphs</a>
        </div>
    </div>
    <table id='Summary' class='Display'>
        <thead>
        <tr>
            <th>VMIP</th>
            <th>vmname</th>
            <th>ThinClientIP</th>
            <th>grp</th>
        </tr>
        </thead>
        <tbody>
        <?php
        // Create a connection
        $conn = new mysqli('localhost', 'root', '', 'task2');

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $start = $_POST['start-date'];
            $end = $_POST['end-date'];
            $answer = $_POST["selected_option"];
            echo "<h3><pre> Selected group: $answer   Start-date: $start   End-date: $end</h3>";

            $sql = "SELECT VMIP,vmname,ThinClientIP,grp FROM vdi where grp='$answer' and DATE_FORMAT(STR_TO_DATE(AssignedDate, '%d.%m.%Y'), '%Y-%m-%d')  between '$start' and '$end'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["VMIP"] . "</td>";
                    echo "<td>" . $row["vmname"] . "</td>";
                    echo "<td>" . $row["ThinClientIP"] . "</td>";
                    echo "<td>" . $row["grp"] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='3'>No records found</td></tr>";
            }
        }

        $conn->close();
        ?>
        </tbody>

    </table>
    <script type="text/javascript">
            $(document).ready(function() {
                $('#Summary').DataTable();
            });
    </script>
    
    <script>
        function redirectTo(pageUrl) {
            window.location.href = pageUrl;
        }
    </script>
</body>

</html>