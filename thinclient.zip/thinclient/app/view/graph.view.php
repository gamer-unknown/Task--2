<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Analysis</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url('../assets/stats.png') no-repeat center center fixed;
            background-size: cover;
            min-height: 30vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }

        .header {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            top: 0;
        }

        .options {
            margin-left: 20px;
            display: flex;
            align-items: center;
        }

        .options a {
            color: white;
            text-decoration: none;
            margin-right: 20px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="header">
        <div class="options">
            <a href="table">Table</a>
            <a href="graph">Graphs</a>
        </div>
    </div>
    <h1>Graph Generation</h1>
    <form method="post">
        <label for="start-date">Start Date:</label>
        <input type="date" id="start-date" name="start-date" required>
        <label for="end-date">End Date:</label>
        <input type="date" id="end-date" name="end-date">
        <input id="submit-button" type="submit" value="Submit">
    </form>

    <script>
        function redirectTo(pageUrl) {
            window.location.href = pageUrl;
        }
    </script>
</body>

</html>