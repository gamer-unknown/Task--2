<?php

class Table 
{
    public function index()
    {
        $filename = '../app/view/table.view.php';
        require $filename;
    }
}


$obj = new Table;
$obj->index();