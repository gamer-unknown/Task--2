<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Analysis</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url('../assets/stats.png') no-repeat center center fixed;
            background-size: cover;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }

        .header {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            top: 0;
        }

        .options {
            margin-left: 20px;
            display: flex;
            align-items: center;
        }

        .options a {
            color: white;
            text-decoration: none;
            margin-right: 20px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="header">
        <div class="options">
            <a href="table">Table</a>
            <a href="graph">Graphs</a>
        </div>
    </div>

    <script>
        function redirectTo(pageUrl) {
            window.location.href = pageUrl;
        }
    </script>
</body>

</html>

---------------------------------------------------------------------------------


<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "my_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve data from the database
$sql = "SELECT activity_type, COUNT(*) AS count FROM activities GROUP BY activity_type";
$result = $conn->query($sql);

$activityData = array();
while ($row = $result->fetch_assoc()) {
    $activityData[] = $row;
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Activity Data Visualization</title>
    <!-- Load Google Charts API -->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        google.charts.load('current', {'packages':['bar']});
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {
            var data = google.visualization.arrayToDataTable([
                ['Activity Type', 'Count'],
                <?php
                    foreach ($activityData as $row) {
                        echo "['" . $row['activity_type'] . "', " . $row['count'] . "],";
                    }
                ?>
            ]);

            var options = {
                chart: {
                    title: 'Activity Distribution',
                    subtitle: 'Number of people engaged in different activities',
                },
                bars: 'vertical'
            };

            var chart = new google.charts.Bar(document.getElementById('chart_div'));

            chart.draw(data, google.charts.Bar.convertOptions(options));
        }
    </script>
</head>
<body>
    <div id="chart_div" style="width: 800px; height: 400px;"></div>
</body>
</html>
