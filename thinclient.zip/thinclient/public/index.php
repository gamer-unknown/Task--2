<?php


class App
{
    private $controller='Home';
    private $method='index';

    public function splitURL(){
        $URL=$_GET['url'] ?? 'table';
        $URL=explode('/',$URL); 
        return $URL;
    }

    public function getController(){
        $URL=$this->splitURL();
        $filename="../app/controller/".ucfirst($URL[0]).".php";
        if(file_exists($filename))
        {
            require $filename;
        }
        else{
            $filename="../app/controller/_404.php";
            require $filename;
        }
    }
}

$obj = new App;
$obj->getController();