<?php

class Graph
{
    public function index()
    {
        $filename = '../app/view/graph.view.php';
        require $filename;
    }
}

$obj = new Graph;
$obj->index();